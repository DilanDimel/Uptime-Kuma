module.exports = {
    "rootDir": "..",
    "testRegex": "./test/backend.spec.js",
};

