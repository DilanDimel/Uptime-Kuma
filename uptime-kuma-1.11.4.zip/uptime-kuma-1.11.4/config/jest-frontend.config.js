module.exports = {
    "rootDir": "..",
    "testRegex": "./test/frontend.spec.js",
};

